# импортируем библиотеки
from flask import Flask, request
import logging
from main import main, create_level
from app_image import *

# библиотека, которая нам понадобится для работы с JSON
import json

# создаём приложение
# мы передаём __name__, в нём содержится информация,
# в каком модуле мы находимся.
# В данном случае там содержится '__main__',
# так как мы обращаемся к переменной из запущенного модуля.
# если бы такое обращение, например, произошло внутри модуля logging,
# то мы бы получили 'logging'
app = Flask(__name__)

# Устанавливаем уровень логирования
logging.basicConfig(level=logging.INFO)

# Создадим словарь, чтобы для каждой сессии общения с навыком хранились
# подсказки, которые видел пользователь.
# Это поможет нам немного разнообразить подсказки ответов
# (buttons в JSON ответа).
# Когда новый пользователь напишет нашему навыку, то мы сохраним
# в этот словарь запись формата
# sessionStorage[user_id] = {'suggests': ["Не хочу.", "Не буду.", "Отстань!"]}
# Такая запись говорит, что мы показали пользователю эти три подсказки.
# Когда он откажется купить слона,
# то мы уберем одну подсказку. Как будто что-то меняется :)
sessionStorage = {}


class main_dialog():
    def __init__(self):
        self.map_request = None
        self.slovar_info_st = None
        self.YA = None
        self.slovar_names = None
        self.places = None
        self.main = None

    def handle_dialog(self, req, res):
        user_id = req['session']['user_id']

        # sessionStorage[user_id] = {
        #    'suggests': []
        # }

        if req['session']['new']:
            # Это новый пользователь.
            # Инициализируем сессию и поприветствуем его.
            # Заполняем текст ответа
            res['response']['text'] = "Привет, хочешь поиграть в \"Метро\"?"
            # Получим подсказки
            # res['response']['buttons'] = self.get_suggests(user_id)
            return

        # если игра еще не началась
        if self.map_request == None:
            if req['request']['original_utterance'].lower() in [
                'ладно',
                'да',
                'давай',
                'играем',
                'погнали'
            ]:
                res['response']['text'] = 'Ваша задача: собрать всех пассажиров с определённых станциях' \
                                          ' (эти точки отмечены синим цветом) и доставить их на главную базу (домик),' \
                                          ' на которой вы сейчас находитесь.' \
                                          ' На борт можно взять только ОДНОГО пассажира. На карте показаны опасные зоны' \
                                          ' (оранжевые), в них лучше не попадать - будет отниматься здоровье,' \
                                          ' но его можно пополнять не только на главной базе, а еще и на' \
                                          ' перевалочных пунктах (фиолетовый цвет). \n' \
                                          '\'статистика\' - посмотреть статистику персонажа \n '\
                                          '\'закрыть\' - завершить игру \n ' \
                                          'Отправьте любое сообщение, чтобы продолжить'
            else:
                res['response']['text'] = 'И да, отказы не принимаются! Ваша задача: собрать всех пассажиров с определённых станциях' \
                                          ' (эти точки отмечены синим цветом) и доставить их на главную базу (домик),' \
                                          ' на которой вы сейчас находитесь.' \
                                          ' На борт можно взять только ОДНОГО пассажира. На карте показаны опасные зоны' \
                                          ' (оранжевые), в них лучше не попадать - будет отниматься здоровье,' \
                                          ' но его можно пополнять не только на главной базе, а еще и на' \
                                          ' перевалочных пунктах (фиолетовый цвет). \n' \
                                          '\'статистика\' - посмотреть статистику персонажа \n ' \
                                          '\'закрыть\' - завершить игру \n' \
                                          'Отправьте любое сообщение, чтобы продолжить'
            self.map_request, self.slovar_info_st, self.YA, self.slovar_names, self.places = create_level()
            self.main = main(self.map_request, self.slovar_info_st, self.YA, self.slovar_names, self.places, 0.1)
            return
        # если она уже в процессе
        else:
            if req['request']['original_utterance'].lower() in [
                "закрыть",
                "не хочу играть",
                "close",
                "больше не хочу",
                "закрой игру"
            ]:
                res['response']['text'] = "Спасибо за игру! ;)"
                res['response']['end_session'] = True
                del_all_images()
                return
            res['response']['text'] = self.main.get_exodus(req['request']['original_utterance'],
                                                           self.main.get_choice_path())
            res['response']['text'] = res['response']['text'] + '\n' + self.main.get_position() + '\n' + self.main.get_mb_ways()
            if req['request']['original_utterance'].lower() in [
                "cтатистика",
                "стата",
                "state"
            ]:
                return
            if "Вы погибли! Задание провалено." in res['response'][
                'text'] or "Вы доставили последнего пассажира! Задание выполнено!" in res['response']['text']:
                res['response']['end_session'] = True
                del_all_images()
                return
            res['response']['buttons'] = self.get_suggests(user_id)
            res['response']['card'] = {}
            res['response']['card']['type'] = 'BigImage'
            res['response']['card']['title'] = self.main.get_mb_ways()
            id = get_image(self.main.create_map(self.main.get_response()))['image']['id']
            res['response']['card']['image_id'] = id

            #del_image(id)

    def get_suggests(self, user_id):
        # session = sessionStorage[user_id]
        sp = []
        for suggest in self.main.get_choice_path():
            sp.append(suggest)
        sp.append("остаться")

        suggests = [
            {'title': suggest, 'hide': True}
            for suggest in sp
        ]

        # session['suggests'] = []
        # sessionStorage[user_id] = session

        return suggests

main_dialog = main_dialog()


@app.route('/post', methods=['POST'])
# Функция получает тело запроса и возвращает ответ.
# Внутри функции доступен request.json - это JSON,
# который отправила нам Алиса в запросе POST
def Main():
    logging.info('Request: %r', request.json)

    # Начинаем формировать ответ, согласно документации
    # мы собираем словарь, который потом при помощи библиотеки json
    # преобразуем в JSON и отдадим Алисе
    response = {
        'session': request.json['session'],
        'version': request.json['version'],
        'response': {
            'end_session': False
        }
    }

    # Отправляем request.json и response в функцию handle_dialog.
    # Она сформирует оставшиеся поля JSON, которые отвечают
    # непосредственно за ведение диалога
    main_dialog.handle_dialog(request.json, response)

    logging.info('Response: %r', request.json)

    # Преобразовываем в JSON и возвращаем
    return json.dumps(response)


if __name__ == '__main__':
    app.run()
