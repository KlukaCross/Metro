import requests

url = "https://dialogs.yandex.net/api/v1/skills/f8a6857a-4ff5-4010-b119-59e983636324/images"


def get_images():
    payload = ""
    headers = {
        'Authorization': "OAuth AQAAAAARL49BAAT7oyCpipuYH0XbvuQgxPV6NrQ",
        'Host': "dialogs.yandex.net"
        }

    response = requests.request("GET", url, data=payload, headers=headers)

    return response.json()


def get_image(filename):
    files = {'file': (open(filename, 'rb'))}
    #print(files)
    headers = {
        'Authorization': "OAuth AQAAAAARL49BAAT7oyCpipuYH0XbvuQgxPV6NrQ"
    }

    response = requests.post(url, files=files, headers=headers)

    return response.json()

#print(get_image("map.PNG"))
def del_image(id):
    payload = ""
    headers = {
        'Authorization': "OAuth AQAAAAARL49BAAT7oyCpipuYH0XbvuQgxPV6NrQ"
    }

    response = requests.request("DELETE", url+"/"+id, data=payload, headers=headers)

    return response.text


def del_all_images():
    images = get_images()["images"]
    for i in images:
        del_image(i["id"])
