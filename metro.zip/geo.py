import requests
import time
from math import sin, cos, sqrt, atan2, radians


def get_info_station(station, priora):
    time.sleep(1)
    url = "https://geocode-maps.yandex.ru/1.x/"
    # apikey=dda3ddba-c9ea-4ead-9010-f43fbc15c6e3
    params = {
        'geocode': station,
        'format': 'json'
    }
    print(station)
    response = requests.get(url, params)
    json = response.json()

    point_array = None
    try:
        point_str = json['response']['GeoObjectCollection']['featureMember'][priora]['GeoObject']['Point']['pos']
        point_array = [float(x) for x in point_str.split(' ')]
    except Exception as e:
        print(e)
        print("Error!", json)
    return point_array


def get_metka(coor, type='', color='', size='', content=''):
    pt = ""
    pt += str(coor[0]) + "," + str(coor[1]) + "," + type + color + size + str(content) + "~"
    return pt


def get_line(vertex, color=''):  # vertex - список, не превышающий 100 элементов
    pl = ""
    pl += "c:" + color + ","
    for i in vertex:
        for j in i:
            pl += str(j) + ","
    pl = pl[:-1]
    #print(pl)
    return pl


def get_distance(p1, p2):

    R = 6373.0

    lon1 = radians(p1[0])
    lat1 = radians(p1[1])
    lon2 = radians(p2[0])
    lat2 = radians(p2[1])

    dlon = lon2 - lon1
    dlat = lat2 - lat1

    a = sin(dlat / 2) ** 2 + cos(lat1) * cos(lat2) * sin(dlon / 2) ** 2
    c = 2 * atan2(sqrt(a), sqrt(1 - a))

    distance = R * c

    return distance

