from stations import get_coors_stations, gray_line, green_line, blue_line, centre_line, pink_line, slovar_color, sort_val, slovar_path, slovar_info
from const_metro_types import *
from geo import get_metka, get_line
import requests
import random
import sys
import pygame
import os

spn = 0.1


def create_level():
    map_request = "http://static-maps.yandex.ru/1.x/"  # вся Москва
    map_request += "?ll="
    map_request += "&spn="
    all_stations = []
    all_stations.append(gray_line)
    all_stations.append(green_line)
    #all_stations.append(blue_line)
    #all_stations.append(red_line)
    all_stations.append(centre_line)
    all_stations.append(pink_line)

    tested_sp = []

    slovar_info_st = {}

    slovar_names = {}

    random_line = random.choice(all_stations)
    random_station = random.choice(random_line)
    map_request += "&pt="
    map_request += get_metka(random_station, "ya_ru")
    #map_request += get_metka(random_station, "home")
    YA = str(random_station[0]) + " " + str(random_station[1])
    map_request = change_ll(map_request, random_station)
    slovar_info_st[str(random_station[0]) + " " + str(random_station[1])] = "HOME"
    tested_sp.append(random_station)
    slovar_names[str(random_station[0]) + " " + str(random_station[1])] = "HOME"

    N = 1
    places = 0
    for i in range(len(all_stations)):
        for j in range(len(all_stations[i])):
            choice = random.randint(0, 100)
            if all_stations[i][j] not in tested_sp:
                if choice <= 15:
                    map_request += get_metka(all_stations[i][j], "pm", "vv", "s", N)
                    slovar_info_st[str(all_stations[i][j][0]) + " " + str(all_stations[i][j][1])] = "BASE"
                elif choice <= 25:
                    map_request += get_metka(all_stations[i][j], "pm", "bl", "s", N)
                    slovar_info_st[str(all_stations[i][j][0]) + " " + str(all_stations[i][j][1])] = "ARRIVAL"
                    places += 1
                elif choice <= 50:
                    map_request += get_metka(all_stations[i][j], "pm", "or", "s", N)
                    slovar_info_st[str(all_stations[i][j][0]) + " " + str(all_stations[i][j][1])] = "DANGER"
                elif choice <= 100:
                    map_request += get_metka(all_stations[i][j], "pm", "wt", "s", N)
                    slovar_info_st[str(all_stations[i][j][0]) + " " + str(all_stations[i][j][1])] = "CLEAN"
                slovar_names[str(all_stations[i][j][0]) + " " + str(all_stations[i][j][1])] = str(N)
                tested_sp.append(all_stations[i][j])
                N += 1
    #print(len(tested_sp), "==", len(slovar_names), "==", len(slovar_path))
    map_request = map_request[:-1]

    map_request += "&pl="
    for i in all_stations:
        map_request += get_line(i, slovar_color[str(i[0][0])])
        map_request += "~"
    map_request = map_request[:-1]
    #print(len(tested_sp))
    map_request = change_spn(map_request, spn)
    map_request += "&l=map"
    return map_request, slovar_info_st, YA, slovar_names, places


def change_pt(map_request, val, type_st):
    value = str(val[0]) + " " + str(val[1])
    name = slovar_names[value]
    val = str(val[0]) + "," + str(val[1])
    map = map_request.split("&pt=")
    index = map[1].index(val)
    if name != "80":
        index2 = map[1][index:].index("~")
    else:
        index2 = map[1][index:].index("&")
    # print(index,index2)
    if type_st == "home" or type_st == "ya_ru":
        return map[0] + "&pt=" + map[1][:index] + val + "," + type_st + map[1][index:][index2:]
    else:
        return map[0] + "&pt=" + map[1][:index] + val + "," + type_st + name + map[1][index:][index2:]


def change_spn(map_request, val):
    map = map_request.split("&spn=")
    index = map[1].index("&")
    return map[0] + "&spn=" + str(val) + "," + str(val) + map[1][index:]


def change_ll(map_request, val):
    map = map_request.split("?ll=")
    index = map[1].index("&")
    return map[0] + "?ll=" + str(val[0]) + "," + str(val[1]) + map[1][index:]


class main:
    def __init__(self, map_request, slovar_info_st, YA, slovar_names, places, spn):
        self.map_request = map_request
        self.slovar_info_st = slovar_info_st
        self.YA = YA
        self.slovar_names = slovar_names
        self.places = places
        self.spn = spn
        self.player = Player()
        #self.main_loop()

    def get_info_station(self, val):
        name = slovar_names[val]

        val = val.split(" ")
        val = str(val[0]) + "," + str(val[1])
        map = self.map_request.split("&pt=")
        index = map[1].index(val)
        if name != "80":
            index2 = map[1][index:].index("~")
        else:
            index2 = map[1][index:].index("&")
        if len(name) == 4:
            return "home"
        else:
            #print("info:", map[1][index+len(val)+1:index+index2-len(name)])
            return map[1][index+len(val)+1:index+index2-len(name)]
    def get_response(self):
        return requests.get(self.map_request)

    def create_map(self, response):
        # Зaпишем полученное изображение в файл.
        map_file = "map.png"
        try:
            with open(map_file, "wb") as file:
                file.write(response.content)
        except IOError as ex:
            print("Ошибка записи временного файла:", ex)
            sys.exit(2)
        return map_file

    def get_choice_path(self):
        ways = []
        ya = self.YA.split(" ")
        choice = slovar_path[ya[0] + " " + ya[1]]
        #print("choice:", choice)
        sp_choice = sort_val(choice)
        for i in range(len(sp_choice)):
            ways.append(self.slovar_names[sp_choice[i]])
        #print("ways:",ways)
        return ways

    def get_station(self, name):
        for k in self.slovar_names:
            if self.slovar_names[k] == name:
                return k

    def get_position(self):
        #map_file = self.create_map(self.get_response())
        st = ""
        #pygame.init()
        #screen = pygame.display.set_mode((600, 450))
        #screen.blit(pygame.image.load(map_file), (0, 0))
        #pygame.display.flip()
        #running = True
        #while running:
        #    for event in pygame.event.get():
        #        if event.type == pygame.QUIT:
        #            running = False
        #            pygame.quit()
        hp, bear, effect, point = self.player.get_state()
        if hp <= 0 or point == self.places:
            if hp <= 0:
                return "Вы погибли! Задание провалено."
            elif point == self.places:
                return "Вы доставили последнего пассажира! Задание выполнено!"
            pygame.quit()
            #break
        st += "Вы находитесь на станции №" + self.slovar_names[self.YA]
        st += get_human_state(hp, bear, effect, point)
        ways = self.get_choice_path()
        st += "Возможные пути: "
        for i in ways:
            st += i + ', '
        st += "остаться"
        return st
        #act = input()
        #if act == "close":
        #    pygame.quit()
    def get_exodus(self, act, ways):
        act = act.lower()
        st = ''
        prev_station = [self.YA.split(" "), "home"]
        if act == "+" or act == "-":
            if act == "-":
                if self.spn >= 0.005:
                    if self.spn / 1.5 >= 0.001:
                        self.spn /= 1.5
                        self.map_request = change_spn(self.map_request, self.spn)
                        #print("-", self.spn)
            elif act == "+":
                if self.spn <= 0.25:
                    if self.spn * 1.5 <= 0.34:
                        self.spn *= 1.5
                        self.map_request = change_spn(self.map_request, self.spn)
                        #print("+", self.spn)
            #os.remove(map_file)
            #map_file = self.create_map(self.get_response())
            #screen.blit(pygame.image.load(map_file), (0, 0))
            #pygame.display.flip()
        elif act in ways:
            self.map_request = change_pt(self.map_request, prev_station[0], prev_station[1])
            next_station = self.get_station(act)
            prev_station = [next_station.split(" "), self.get_info_station(next_station)]
            #print(self.get_info_station(next_station))
            # print("next_station:", next_station)
            act = next_station.split(" ")
            self.map_request = change_pt(self.map_request, act, "ya_ru")
            self.map_request = change_ll(self.map_request, act)
            self.YA = str(act[0]) + " " + str(act[1])
            #try:
            #    os.remove(map_file)
            #    map_file = self.create_map(self.get_response())
            #    screen.blit(pygame.image.load(map_file), (0, 0))
            #    pygame.display.flip()
            #except Exception as e:
            #    print(e)
            #print(self.map_request)
            prev_station = [prev_station[0], self.player.main_loop(self.YA, prev_station[1])]
            self.slovar_info_st[prev_station[0][0] + " " + prev_station[0][1]] = slovar_info[prev_station[1]]
            st += "Вы переместились на станцию №" + self.slovar_names[self.YA]
        elif act == "остаться" or act == "ничего не делать":
            self.player.main_loop(self.YA)
            st += "Вы остаётесь на месте"
        else:
            st += "Выберите один из вариантов ответа!"
        #os.remove(map_file)
        return st

class Player():
    def __init__(self):
        self.hp = 100
        self.point = 0
        self.bear = 0
        self.effect = "HOME"

    def main_loop(self, val, info=''):
        self.effect = slovar_info_st[val]
        mb_st = info
        if self.effect == "HOME":
            self.hp += 20
            if self.bear == 1:
                self.point += 1
                print("Вы доставили пассажира!")
            self.bear = 0
            print("Вы находитесь на главной базе")
        elif self.effect == "BASE":
            self.hp += 100
            print("Вы находитесь на перевалочном пункте")
        elif self.effect == "ARRIVAL":
            if self.bear == 0:
                self.bear = 1
                mb_st = "pmwts"

                print("Вы забираете пассажира, его нужно доставить на главную базу!")
            else:
                print("Вы не можете забрать пассажира: места переполнены!")
        elif self.effect == "DANGER":
            self.hp -= 10
            print("Вы находитесь в опасном месте, убирайтесь отсюда!")
        elif self.effect == "CLEAN":
            self.hp += 1
            print("Вы находитесь в безопасном месте")
        if self.hp > 100:
            self.hp = 100
        return mb_st

    def get_state(self):
        return self.hp, self.bear, self.effect, self.point


def get_human_state(hp, bear, effect, point):
    st = ""
    st += "Здоровье: " + str(hp) + "\n"
    st += "Пассажиров на борту: " + str(bear) + "\n"
    st += "Осталось доставить: " + str((places - point)) + "\n"
    #if effect == "HOME":
    #    if bear == 1:
    #        st += "Вы доставили пассажира!" + "\n"
    #    st += "Вы находитесь на главной базе"
    #elif effect == "BASE":
    #    st += "Вы находитесь на перевалочном пункте"
    #elif effect == "ARRIVAL":
    #    if bear == 0:
    #        st += "Вы забираете пассажира, его нужно доставить на главную базу!"
    #    elif bear == 1:
    #        st += "Вы не можете забрать пассажира: места переполнены!"
    #elif effect == "CLEAN":
    #    st += "Вы находитесь в безопасном месте"
    #elif effect == "DANGER":
    #    st += "Вы находитесь в опасном месте, убирайтесь отсюда!"
    return st


#map_request, slovar_info_st, YA, slovar_names, places = create_level()

#prev_station = [YA.split(" "), "home"]

#pygame.quit()

#map_request, slovar_info_st, YA, slovar_names, places = create_level()
#main(map_request, slovar_info_st, YA, slovar_names, places, spn)

if __name__ == '__main__':
    map_request, slovar_info_st, YA, slovar_names, places = create_level()
    main(map_request, slovar_info_st, YA, slovar_names, places, spn)
