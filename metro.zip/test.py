s = "asdasd"
print(s.split(","))